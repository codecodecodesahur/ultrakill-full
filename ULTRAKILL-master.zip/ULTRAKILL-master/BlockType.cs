public enum BlockType
{
	PlasticGeneric,
	Wood,
	Metal,
	Water,
	Grass,
	Glass,
	HotSand,
	Lava,
	Acid
}
