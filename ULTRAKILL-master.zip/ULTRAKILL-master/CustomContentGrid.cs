using UnityEngine;

public class CustomContentGrid : MonoBehaviour
{
	public GameObject grid;
}
