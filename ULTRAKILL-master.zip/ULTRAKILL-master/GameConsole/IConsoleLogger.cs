using plog;

namespace GameConsole;

public interface IConsoleLogger
{
	Logger Log { get; }
}
