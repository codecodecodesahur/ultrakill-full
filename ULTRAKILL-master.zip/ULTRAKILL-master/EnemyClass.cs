public enum EnemyClass
{
	Husk,
	Machine,
	Demon,
	Divine,
	Other
}
