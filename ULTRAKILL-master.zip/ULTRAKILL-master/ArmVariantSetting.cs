using System;

[Serializable]
public class ArmVariantSetting
{
	public VariantOption blueVariant;

	public VariantOption redVariant;

	public VariantOption greenVariant;
}
