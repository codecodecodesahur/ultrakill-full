namespace Discord;

public struct PartySize
{
	public int CurrentSize;

	public int MaxSize;
}
