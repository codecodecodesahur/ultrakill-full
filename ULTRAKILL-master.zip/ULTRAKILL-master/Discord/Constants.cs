namespace Discord;

internal static class Constants
{
	public const string DllName = "discord_game_sdk";
}
