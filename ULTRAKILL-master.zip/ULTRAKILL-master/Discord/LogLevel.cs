namespace Discord;

public enum LogLevel
{
	Error = 1,
	Warn,
	Info,
	Debug
}
