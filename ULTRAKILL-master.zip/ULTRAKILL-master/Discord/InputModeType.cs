namespace Discord;

public enum InputModeType
{
	VoiceActivity,
	PushToTalk
}
