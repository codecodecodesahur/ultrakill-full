namespace Discord;

public struct ActivityTimestamps
{
	public long Start;

	public long End;
}
