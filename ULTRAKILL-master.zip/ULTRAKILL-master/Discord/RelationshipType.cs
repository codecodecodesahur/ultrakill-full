namespace Discord;

public enum RelationshipType
{
	None,
	Friend,
	Blocked,
	PendingIncoming,
	PendingOutgoing,
	Implicit
}
