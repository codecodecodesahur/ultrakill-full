namespace Discord;

public enum ImageType
{
	User
}
