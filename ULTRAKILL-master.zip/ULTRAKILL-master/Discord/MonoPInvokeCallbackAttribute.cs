using System;

namespace Discord;

internal class MonoPInvokeCallbackAttribute : Attribute
{
}
