namespace Discord;

public enum UserFlag
{
	Partner = 2,
	HypeSquadEvents = 4,
	HypeSquadHouse1 = 0x40,
	HypeSquadHouse2 = 0x80,
	HypeSquadHouse3 = 0x100
}
