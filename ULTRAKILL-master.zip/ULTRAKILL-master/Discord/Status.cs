namespace Discord;

public enum Status
{
	Offline,
	Online,
	Idle,
	DoNotDisturb
}
