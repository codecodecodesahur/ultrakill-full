namespace Discord;

public enum ActivityType
{
	Playing,
	Streaming,
	Listening,
	Watching
}
