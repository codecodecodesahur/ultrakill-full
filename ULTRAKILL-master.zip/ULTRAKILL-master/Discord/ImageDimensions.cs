namespace Discord;

public struct ImageDimensions
{
	public uint Width;

	public uint Height;
}
