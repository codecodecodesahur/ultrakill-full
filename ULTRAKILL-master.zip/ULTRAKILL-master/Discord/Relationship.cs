namespace Discord;

public struct Relationship
{
	public RelationshipType Type;

	public User User;

	public Presence Presence;
}
