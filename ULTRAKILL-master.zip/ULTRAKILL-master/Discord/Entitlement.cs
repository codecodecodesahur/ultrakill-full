namespace Discord;

public struct Entitlement
{
	public long Id;

	public EntitlementType Type;

	public long SkuId;
}
