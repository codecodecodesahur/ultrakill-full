namespace Discord;

public enum SkuType
{
	Application = 1,
	DLC,
	Consumable,
	Bundle
}
