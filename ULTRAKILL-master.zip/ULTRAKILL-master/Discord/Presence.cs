namespace Discord;

public struct Presence
{
	public Status Status;

	public Activity Activity;
}
