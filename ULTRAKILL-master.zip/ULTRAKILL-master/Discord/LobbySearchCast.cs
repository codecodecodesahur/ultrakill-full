namespace Discord;

public enum LobbySearchCast
{
	String = 1,
	Number
}
