namespace Discord;

public enum ActivityJoinRequestReply
{
	No,
	Yes,
	Ignore
}
