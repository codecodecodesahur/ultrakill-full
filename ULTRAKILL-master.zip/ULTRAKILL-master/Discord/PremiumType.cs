namespace Discord;

public enum PremiumType
{
	None,
	Tier1,
	Tier2
}
