namespace Discord;

public enum LobbyType
{
	Private = 1,
	Public
}
