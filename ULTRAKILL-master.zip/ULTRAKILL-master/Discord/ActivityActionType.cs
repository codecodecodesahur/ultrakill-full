namespace Discord;

public enum ActivityActionType
{
	Join = 1,
	Spectate
}
