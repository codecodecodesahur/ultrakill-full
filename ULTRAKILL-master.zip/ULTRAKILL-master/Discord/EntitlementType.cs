namespace Discord;

public enum EntitlementType
{
	Purchase = 1,
	PremiumSubscription,
	DeveloperGift,
	TestModePurchase,
	FreePurchase,
	UserGift,
	PremiumPurchase
}
