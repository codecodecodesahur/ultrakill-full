namespace Discord;

public enum LobbySearchDistance
{
	Local,
	Default,
	Extended,
	Global
}
