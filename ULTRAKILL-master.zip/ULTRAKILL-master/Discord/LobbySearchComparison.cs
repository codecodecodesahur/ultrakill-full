namespace Discord;

public enum LobbySearchComparison
{
	LessThanOrEqual = -2,
	LessThan,
	Equal,
	GreaterThan,
	GreaterThanOrEqual,
	NotEqual
}
