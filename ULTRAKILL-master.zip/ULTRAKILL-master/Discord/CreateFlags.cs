namespace Discord;

public enum CreateFlags
{
	Default,
	NoRequireDiscord
}
