public enum CopyType
{
	None,
	WeaponIcon,
	WeaponShadow
}
