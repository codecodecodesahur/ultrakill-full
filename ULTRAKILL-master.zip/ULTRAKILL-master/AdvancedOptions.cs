using UnityEngine;

public class AdvancedOptions : MonoBehaviour
{
	public void ResetCyberGrind()
	{
		GameProgressSaver.ResetBestCyber();
	}
}
