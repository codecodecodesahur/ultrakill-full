using UnityEngine;

public class FinalRoom : MonoBehaviour
{
	public Transform dropPoint;

	public GameObject doorOpener;
}
