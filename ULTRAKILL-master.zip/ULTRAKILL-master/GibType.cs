public enum GibType
{
	Brain,
	Skull,
	Eye,
	Jaw,
	Gib
}
