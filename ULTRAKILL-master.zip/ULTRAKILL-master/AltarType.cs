using System;

[Serializable]
public enum AltarType
{
	Blue,
	Red,
	Stone
}
