using System;

[Serializable]
public struct ActivityRankIcon
{
	public string Image;

	public string Text;
}
