using UnityEngine.Events;

public sealed class AnimationEventMessageEvent : UnityEvent<AnimationEvent>
{
}
