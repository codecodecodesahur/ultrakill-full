[ConfigureSingleton(SingletonFlags.NoAutoInstance)]
public class DefaultSandboxCheckpoint : MonoSingleton<DefaultSandboxCheckpoint>
{
	public CheckPoint checkpoint;
}
