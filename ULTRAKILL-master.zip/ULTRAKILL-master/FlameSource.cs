public enum FlameSource
{
	None,
	Streetcleaner,
	Napalm
}
