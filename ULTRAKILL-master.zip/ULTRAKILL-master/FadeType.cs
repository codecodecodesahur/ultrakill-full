public enum FadeType
{
	Sprite,
	Line,
	Light,
	Renderer
}
