public enum ClungMannequinMovementDirection
{
	Horizontal,
	Vertical
}
