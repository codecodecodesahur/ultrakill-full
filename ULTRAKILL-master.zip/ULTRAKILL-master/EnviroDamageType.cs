public enum EnviroDamageType
{
	Normal,
	Burn,
	Acid,
	WeakBurn,
	Chainsaw
}
