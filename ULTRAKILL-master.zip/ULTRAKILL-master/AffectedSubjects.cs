public enum AffectedSubjects
{
	All,
	PlayerOnly,
	EnemiesOnly
}
