public enum GabrielWeaponType
{
	Sword,
	Zweihander,
	Axe,
	Spear,
	Glaive
}
