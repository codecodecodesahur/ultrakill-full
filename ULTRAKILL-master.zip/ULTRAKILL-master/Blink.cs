using UnityEngine;

public class Blink : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
