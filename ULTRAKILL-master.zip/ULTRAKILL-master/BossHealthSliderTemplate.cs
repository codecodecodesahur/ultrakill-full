using UnityEngine;
using UnityEngine.UI;

public class BossHealthSliderTemplate : MonoBehaviour
{
	public Slider slider;

	public Image fill;

	public GameObject filler;

	public GameObject background;
}
