using TMPro;
using UnityEngine;

public class CustomContentCategory : MonoBehaviour
{
	public TMP_Text title;
}
