public enum DoorType
{
	Normal,
	BigDoorController,
	SubDoorController
}
