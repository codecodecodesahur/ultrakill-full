public enum CyberPooledType
{
	None,
	JumpPad
}
