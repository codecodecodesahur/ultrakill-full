public class EnemyTypeTracker
{
	public EnemyType type;

	public int amount;

	public EnemyTypeTracker(EnemyType enemyType)
	{
		type = enemyType;
	}
}
