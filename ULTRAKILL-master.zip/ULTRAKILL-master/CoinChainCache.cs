using System.Collections.Generic;
using UnityEngine;

public class CoinChainCache : MonoBehaviour
{
	public List<GameObject> beenHit = new List<GameObject>();

	public EnemyTarget target;
}
