public enum FishingRodState
{
	ReadyToThrow,
	SelectingPower,
	Throwing,
	WaitingForFish,
	FishStruggle
}
