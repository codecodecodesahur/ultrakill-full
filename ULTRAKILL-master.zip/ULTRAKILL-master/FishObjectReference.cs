using UnityEngine;

public class FishObjectReference : MonoBehaviour
{
	public FishObject fishObject;
}
