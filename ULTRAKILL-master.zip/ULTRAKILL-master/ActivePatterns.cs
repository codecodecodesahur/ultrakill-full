using System;

[Serializable]
public class ActivePatterns
{
	public string[] enabledPatterns;

	public string[] enabledPatternPacks;
}
