using UnityEngine;

public class BloodsplatterSoundpicker : MonoBehaviour
{
	public AudioClip head;

	public AudioClip limb;

	public AudioClip body;
}
