namespace GameConsole.pcon;

public class MapVarField
{
	public string name;

	public MapVarValue value;
}
