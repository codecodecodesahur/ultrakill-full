namespace GameConsole.pcon;

public class MapVarValue
{
	public string type;

	public object value;
}
