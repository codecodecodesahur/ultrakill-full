namespace GameConsole.pcon;

public enum PConLogLevel
{
	CLI,
	Info,
	Warning,
	Error,
	Unknown
}
