public enum BeamType
{
	Revolver,
	Railgun,
	MaliciousFace,
	Enemy
}
