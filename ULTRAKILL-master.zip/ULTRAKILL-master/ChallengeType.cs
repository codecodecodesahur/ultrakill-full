public enum ChallengeType
{
	Succeed,
	Fail
}
