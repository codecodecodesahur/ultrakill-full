using UnityEngine;

[CreateAssetMenu(fileName = "AudioSubtitle", menuName = "ULTRAKILL/Subtitle")]
public class AudioSubtitle : ScriptableObject
{
}
