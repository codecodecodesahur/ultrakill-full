using System;

[Serializable]
public class CampaignLevel
{
	public string uuid;

	public string file;
}
