public enum DecimalType
{
	NoLimit,
	Three,
	Two,
	One,
	NoDecimals
}
