using System;

[Serializable]
public class FishDescriptor
{
	public FishObject fish;

	public int chance = 1;
}
