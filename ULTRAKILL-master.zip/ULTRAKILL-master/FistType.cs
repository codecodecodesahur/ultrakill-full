public enum FistType
{
	Standard,
	Heavy,
	Spear
}
