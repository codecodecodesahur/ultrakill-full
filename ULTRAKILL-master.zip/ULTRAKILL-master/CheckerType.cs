public enum CheckerType
{
	Streetcleaner,
	V2
}
