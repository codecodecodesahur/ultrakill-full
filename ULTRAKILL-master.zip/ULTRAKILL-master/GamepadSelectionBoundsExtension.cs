using UnityEngine;

internal class GamepadSelectionBoundsExtension : MonoBehaviour
{
	public RectTransform[] Transforms;
}
