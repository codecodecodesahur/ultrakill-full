public class CustomGameDetails
{
	public string uniqueIdentifier;

	public int levelNumber;

	public ulong? workshopId;

	public CampaignJson campaign;

	public string campaignId => campaign?.uuid;
}
