using UnityEngine;

public class DestroyOnCheckpointRestart : MonoBehaviour
{
	public bool dontDestroy;
}
