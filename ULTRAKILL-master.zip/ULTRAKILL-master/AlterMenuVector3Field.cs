using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AlterMenuVector3Field : MonoBehaviour
{
	public TMP_Text nameText;

	public InputField xField;

	public InputField yField;

	public InputField zField;
}
