using UnityEngine;
using UnityEngine.UI;

public class BackSelectOverride : MonoBehaviour
{
	[SerializeField]
	public Selectable Selectable;
}
