using UnityEngine;

public class DietProp : MonoBehaviour
{
	public DietProp parent;
}
